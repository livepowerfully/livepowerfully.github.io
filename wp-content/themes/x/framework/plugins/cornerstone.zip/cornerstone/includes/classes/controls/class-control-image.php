<?php
class Cornerstone_Control_Image extends Cornerstone_Control {
	protected $default_context = 'content';
}