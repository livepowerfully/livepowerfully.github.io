<?php

/**
 * Element Defaults: Icon List
 */

return array(
	'id'         => '',
	'class'      => '',
	'style'      => '',
);