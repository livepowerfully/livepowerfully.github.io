<?php

return array(
  'integration-mode'  => null
);
