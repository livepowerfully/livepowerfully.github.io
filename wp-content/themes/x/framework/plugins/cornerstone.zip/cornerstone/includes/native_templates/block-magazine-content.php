<?php return array (
  'title' => 'Magazine Content',
  'elements' =>
  array (
    0 =>
    array (
      'elType' => 'section',
      'title' => 'Magazine Content',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'columnize',
                  'content' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'blockquote',
                  'content' => 'This is where you would put a quote from someone mentioned in the content.',
                  'cite' => 'Citation',
                  'align' => 'center',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'columnize',
                  'content' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'none',
      'bg_color' => '',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'none',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
  ),
);